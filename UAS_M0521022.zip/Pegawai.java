// Nama  : Fitria Rahmadani
// NIM   : M0521022
// Kelas : Informatika A

/**
 * Interface Pegawai digunakan untuk membuat interface
 * Memiliki method hitungGaji yang me-return nilai integer
 */
public interface Pegawai {
    public int hitungGaji();   
}